<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id12789063_zakasih","Panser1932","id12789063_akademik") or die ("could not connect database");
?>